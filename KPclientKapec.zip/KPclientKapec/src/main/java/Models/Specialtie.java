package Models;

import java.io.Serializable;
import java.math.BigDecimal;

public class Specialtie implements Serializable {
    private final int idSpecialtie;
    private final String specialtieName;

    public Specialtie (int idSpecialtie, String specialtieName ){
        this.idSpecialtie = idSpecialtie;
        this.specialtieName = specialtieName;
    }

    public static SpecialtieBuilder builder(){
        return new SpecialtieBuilder();
    }

    public static class SpecialtieBuilder{
        private int idSpecialtie;
        private String specialtieName;

        public SpecialtieBuilder idSpecialtie(int idSpecialtie){
            this.idSpecialtie = idSpecialtie;
            return this;
        }

        public SpecialtieBuilder specialtieName(String specialtieName){
            this.specialtieName = specialtieName;
            return this;
        }

        public Specialtie build(){
            return new Specialtie(idSpecialtie,specialtieName);
        }
    }

    public int getIdSpecialtie() {
        return idSpecialtie;
    }

    public String getSpecialtieName() {
        return specialtieName;
    }

}
