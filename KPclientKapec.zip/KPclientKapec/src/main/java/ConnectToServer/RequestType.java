package ConnectToServer;

import java.io.Serializable;

public enum RequestType implements Serializable {
    REG,
    AUTH
}
