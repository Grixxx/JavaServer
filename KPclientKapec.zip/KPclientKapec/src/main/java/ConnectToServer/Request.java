package ConnectToServer;

import java.io.Serializable;

public class Request implements Serializable {
    public String recMessage;
}